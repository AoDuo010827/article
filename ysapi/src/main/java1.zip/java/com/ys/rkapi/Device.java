package com.ys.rkapi;

/**
 * Created by RYX on 2017/8/30.
 */
enum Device {
    HDMI, LAN, SPEAKER, WIFI, _3G, SD, LED
}
